// $Id: pathauto.js,v 1.4.2.1 2009/04/18 17:10:10 freso Exp $
if (Drupal.jsEnabled) {
  $(document).ready(function() {
    if ($("#edit-pathauto-perform-alias").size() && $("#edit-pathauto-perform-alias").attr("checked")) {
      // Disable input and hide its description.
      $("#edit-path").attr("disabled","disabled");
      $("#edit-path-wrapper > div.description").hide(0);
    }
    $("#edit-pathauto-perform-alias").bind("click", function() {
      if ($("#edit-pathauto-perform-alias").attr("checked")) {
        // Auto-alias checked; disable input.
        $("#edit-path").attr("disabled","disabled");
        $("#edit-path-wrapper > div[class=description]").slideUp('fast');
      }
      else {
        // Auto-alias unchecked; enable input.
        $("#edit-path").removeAttr("disabled");
        $("#edit-path")[0].focus();
        $("#edit-path-wrapper > div[class=description]").slideDown('fast');
      }
    });
  });
}
